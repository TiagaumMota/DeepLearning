# Data Setup

Put the images at the "data/raw_dataset/images" folder and then run the file "script_features.py" (python3 src/script_features.py) to get the extracted features

The extracted features file is on our google drive, inside the folder of "assignments".

# Training and Evaluation
Just run the "train" file, ex:
- python3 src/train.py
- python3 src/train.py --use_attention
